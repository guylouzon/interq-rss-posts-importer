<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * The class that handles the admin screen
 *
 * @author mobilova UG (haftungsbeschränkt) <rsspostimporter@feedsapi.com>
 */
class InterQ_Rss_Pi_Admin {

    /**
     * The options
     *
     * @var array
     */
    public array $options;

    /**
     * Logging instance
     * @var InterQ_Rss_Pi_Log
     */
    public InterQ_Rss_Pi_Log $log;

    /**
     * Form processor instance
     * @var InterQ_Rss_Pi_Admin_Processor
     */
    public InterQ_Rss_Pi_Admin_Processor $processor;

    /**
     *  Start
     *
     * @global object $interq_rss_post_importer
     */
    public function __construct() {

        $this->load_options();

        // initialise logging
        $this->log = new InterQ_Rss_Pi_Log();
        $this->log->init();

        // load the form processor
        $this->processor = new InterQ_Rss_Pi_Admin_Processor();
    }

    private function load_options(): void {
        global $interq_rss_post_importer;

        // add options
        $this->options = $interq_rss_post_importer->options;

    }

    /**
     * Initialise and hook all actions
     */
    public function init(): void {

        // add to admin menu
        add_action('admin_menu', [$this, 'admin_menu']);

        // process and save options prior to screen ui display
        add_action('load-settings_page_interq_rss_pi', [$this, 'save_options']);

        // load scripts and styles we need
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);

        // manage meta data on post deletion and restoring
        add_action('wp_trash_post', [$this, 'delete_post']); // trashing a post
//		add_action('before_delete_post', [$this, 'delete_post']); // deleting a post permanently
        add_action('untrash_post', [$this, 'restore_post']); // restoring a post from trash

        // the ajax for adding new feeds (table rows)
        add_action('wp_ajax_interq_rss_pi_add_row', [$this, 'add_row']);

        // the ajax for editing a feed row
        add_action('wp_ajax_interq_rss_pi_edit_row', [$this, 'edit_row']);

        // the ajax for stats chart
        add_action('wp_ajax_interq_rss_pi_stats', [$this, 'ajax_stats']);

        // the ajax for importing feeds via admin
        add_action('wp_ajax_interq_rss_pi_import', [$this, 'ajax_import']);

        // Add 10 minutes in frequency.
        add_filter('cron_schedules', [$this, 'interq_rss_pi_cron_add']);

        add_filter('cron_schedules', [$this, 'interq_rss_pi_cron_add_custom']);

        // the manual "Fetch Now" import trigger
        add_action('admin_post_interq_rss_pi_fetch_now', [$this, 'fetch_now']);

    }

    /**
     * Manually import all active feeds ("Fetch Now" button).
     * Runs the same import the scheduled cron event runs.
     */
    public function fetch_now(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Sorry, you are not allowed to do this.', 'interq-rss-posts-importer' ) );
        }

        check_admin_referer( 'interq_rss_pi_fetch_now_action', 'interq_rss_pi_fetch_now_nonce' );

        global $interq_rss_post_importer;

        $engine = new InterQ_Rss_Pi_Engine();
        $post_count = $engine->import_feed();

        wp_redirect( add_query_arg(
            [
                'fetch_now' => 'done',
                'imported'  => $post_count,
            ],
            $interq_rss_post_importer->page_link
        ) );
        exit;
    }

    /**
     * Add to admin menu
     */
    public function admin_menu(): void {
        add_options_page('InterQ Rss Post Importer', 'InterQ Rss Post Importer', 'manage_options','interq_rss_pi', [$this, 'screen']);
    }

    /**
     * Enqueue our admin css and js
     *
     * @param string $hook The current screens hook
     * @return void
     */
    public function enqueue(string $hook): void {

        // don't load if it isn't our screen
        if ($hook != 'settings_page_interq_rss_pi') {
            return;
        }

        // register scripts & styles
        wp_enqueue_style('rss-pi', INTERQ_RSS_PI_URL . 'app/assets/css/style.css', [], INTERQ_RSS_PI_VERSION);

        //wp_enqueue_style('rss-pi-jquery-ui-css', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.21/themes/redmond/jquery-ui.css', [], INTERQ_RSS_PI_VERSION);

        wp_enqueue_script('jquery-ui-core');
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_script('jquery-ui-progressbar');

        wp_enqueue_script('modernizr', INTERQ_RSS_PI_URL . 'app/assets/js/modernizr.custom.32882.js', [], INTERQ_RSS_PI_VERSION, true);
        wp_enqueue_script('phpjs-uniqid', INTERQ_RSS_PI_URL . 'app/assets/js/uniqid.js', [], INTERQ_RSS_PI_VERSION, true);
        wp_enqueue_script('rss-pi', INTERQ_RSS_PI_URL . 'app/assets/js/main.js', ['jquery'], INTERQ_RSS_PI_VERSION, true);
        wp_enqueue_script('rss-pi-admin', INTERQ_RSS_PI_URL . 'app/assets/js/rsspiadmin.js', ['jquery'], INTERQ_RSS_PI_VERSION, true);
        wp_register_script(
                'rss-pi-import-trigger', 
                INTERQ_RSS_PI_URL . 'app/assets/js/admin-import.js', 
                ['rss-pi'], 
                INTERQ_RSS_PI_VERSION, 
                true
            );

        // localise ajaxurl and nonce for use
        $localise_args = [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'pluginurl' => INTERQ_RSS_PI_URL,
            'nonce' => wp_create_nonce('interq_rss_pi_ajax_nonce_action'),
            'l18n' => [
                'unsaved' => __( 'You have unsaved changes on this page. Do you want to leave this page and discard your changes or stay on this page?', 'interq-rss-posts-importer' )
            ]
        ];
        wp_localize_script('rss-pi', 'interq_rss_pi', $localise_args);
    }

    // add post URL to interq_rss_pi_deleted_posts when trashing
    public function delete_post(int $post_id): void {
        $interq_rss_pi_deleted_posts = get_option( 'interq_rss_pi_deleted_posts', [] );
        $source_md5 = get_post_meta($post_id, 'rss_pi_source_md5', true);
        if ( $source_md5 && ! in_array( $source_md5, $interq_rss_pi_deleted_posts ) ) {
            // add this source URL hash to the "deleted" metadata
            $interq_rss_pi_deleted_posts[] = $source_md5;
            update_option('interq_rss_pi_deleted_posts', $interq_rss_pi_deleted_posts);
        }
    }

    // remove post URL from interq_rss_pi_deleted_posts when restoring from trash
    public function restore_post(int $post_id): void {
        $interq_rss_pi_deleted_posts = get_option( 'interq_rss_pi_deleted_posts', [] );
        $source_md5 = get_post_meta($post_id, 'rss_pi_source_md5', true);
        if ( $source_md5 && in_array( $source_md5, $interq_rss_pi_deleted_posts ) ) {
            // remove this source URL hash from the "deleted" metadata
            $interq_rss_pi_deleted_posts = array_diff( $interq_rss_pi_deleted_posts, [ $source_md5 ] );
            update_option('interq_rss_pi_deleted_posts', $interq_rss_pi_deleted_posts);
        }
    }

    public function interq_rss_pi_cron_add(array $schedules): array {

        $schedules['minutes_10'] = [
            'interval' => 600,
            'display' => '10 minutes'
        ];

        return $schedules;
    }

    // this will fetch custom frequency
    public function interq_rss_pi_cron_add_custom(array $schedules): array {

        // min in sec
        $rss_min = 60;
        $custom_cron_options = get_option('interq_rss_pi_custom_cron_frequency', []);
        if(! empty($custom_cron_options)) {
            $rss_custom_cron    = @unserialize($custom_cron_options);
            if (is_array($rss_custom_cron) && isset($rss_custom_cron['frequency'], $rss_custom_cron['time'])) {
                $rss_frequency_cron = $rss_custom_cron['frequency'];
                $rss_frequency_time = $rss_custom_cron['time'];
                // Adding custom cron
                $schedules[$rss_frequency_cron] = [
                    'interval' => $rss_min * $rss_frequency_time,
                    'display' => $rss_frequency_time . ' minutes'
                ];
            }
        }

        return $schedules;
    }

    /**
     * save any options submitted before the screen/ui get displayed
     */
    public function save_options(): void {

        // load the form processor
        $this->processor->process();

        // purge "deleted posts" cache when requested
        $this->processor->purge_deleted_posts_cache();
    }

    /**
     * Display the screen/ui
     */
    public function screen(): void {
        // Reload the options to ensure we have current data
        $this->load_options();

        // Use filter_input for cleaner, sanitized access to $_GET variables
        $deleted_cache_purged = filter_input( INPUT_GET, 'deleted_cache_purged', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
        $settings_updated     = filter_input( INPUT_GET, 'settings-updated', FILTER_VALIDATE_BOOLEAN );
        $import_requested     = filter_input( INPUT_GET, 'import', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
        $fetch_now_done       = filter_input( INPUT_GET, 'fetch_now', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
        $fetch_now_count      = filter_input( INPUT_GET, 'imported', FILTER_VALIDATE_INT );

        if ( 'done' === $fetch_now_done ) {
            $fetch_now_count = $fetch_now_count ?: 0;
            echo '<div id="message" class="updated"><p><strong>' .
                esc_html(
                    sprintf(
                        /* translators: %d: number of posts imported */
                        _n( 'Fetch complete: %d new post imported.', 'Fetch complete: %d new posts imported.', $fetch_now_count, 'interq-rss-posts-importer' ),
                        $fetch_now_count
                    )
                ) . '</strong></p></div>';
        }

        // 1. Success Messages
        if ( $deleted_cache_purged || $settings_updated || ( $import_requested && $settings_updated ) ) {
            echo '<div id="message" class="updated">';
            
            if ( 'true' === $deleted_cache_purged ) {
                echo '<p><strong>' . esc_html__( 'Cache for Deleted posts was purged.', 'interq-rss-posts-importer' ) . '</strong></p>';
            }
            
            if ( $settings_updated ) {
                echo '<p><strong>' . esc_html__( 'Settings saved.', 'interq-rss-posts-importer' ) . '</strong></p>';
            }
            
            echo '</div>';

            // 2. Trigger AJAX Import Script
            if ( $import_requested && $settings_updated ) {
                $feed_ids = [];
                if ( ! empty( $this->options['feeds'] ) && is_array( $this->options['feeds'] ) ) {
                    foreach ( $this->options['feeds'] as $f ) {
                        if ( isset( $f['id'] ) ) {
                            $feed_ids[] = $f['id'];
                        }
                    }
                }
            // Pass data and Enqueue the script only now
                wp_localize_script('rss-pi-import-trigger', 'interq_rss_pi_import_data', [
                    'feed_ids' => $feed_ids
                ]);
                wp_enqueue_script('rss-pi-import-trigger');
            }

        }

        global $interq_rss_post_importer;

        // Include the template for the UI
        $template_path = INTERQ_RSS_PI_PATH . 'app/templates/admin-ui.php';
        if ( file_exists( $template_path ) ) {
            include $template_path;
        }
    }

    /**
     * Display errors
     *
     * @param string $error The error message
     * @param bool $inline Whether the error is inline or shown like regular wp errors
     */
    public function key_error(string $error, bool $inline = false): void {

        $class = ($inline) ? 'rss-pi-error' : 'error';

        echo '<div class="' . esc_html($class) . '"><p>' . esc_html($error) . '</p></div>';
    }

    /**
     * Add a new row for a new feed
     */
    public function add_row(): void {
        if (! isset($_POST['feed_id']) || ! isset($_POST['interq_rss_pi_ajax_nonce']) || ! wp_verify_nonce(sanitize_key($_POST['interq_rss_pi_ajax_nonce']), 'interq_rss_pi_ajax_nonce_action')) {
            wp_send_json_error(['message' => 'Invalid request']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }

        $ajax_feed_id = sanitize_key( wp_unslash( $_POST['feed_id'] ) );
        $ajax_add = true;
        include( INTERQ_RSS_PI_PATH . 'app/templates/feed-table-row.php');
        die();
    }

    public function edit_row(): void {
        if (! isset($_POST['feed_id']) || ! isset($_POST['interq_rss_pi_ajax_nonce']) || ! wp_verify_nonce(sanitize_key($_POST['interq_rss_pi_ajax_nonce']), 'interq_rss_pi_ajax_nonce_action')) {
            wp_send_json_error(['message' => 'Invalid request']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }

        $ajax_feed_id = sanitize_key( wp_unslash( $_POST['feed_id'] ) );

        foreach ($this->options['feeds'] as $f) {
            if ($f['id'] == $ajax_feed_id) {
                $ajax_edit = true;
                include( INTERQ_RSS_PI_PATH . 'app/templates/feed-table-row.php');
                die();
            }
        }
    }

    /**
     * Generate stats data and return
     */
    public function ajax_stats(): void {
        if (! isset($_POST['interq_rss_pi_ajax_nonce']) || ! wp_verify_nonce(sanitize_key($_POST['interq_rss_pi_ajax_nonce']), 'interq_rss_pi_ajax_nonce_action')) {
            wp_send_json_error(['message' => 'Invalid request']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }

        $_POST['rss_from_date'] = isset($_POST['rss_from_date']) ? sanitize_text_field(wp_unslash( $_POST['rss_from_date'])) : '';
        $_POST['rss_till_date'] = isset($_POST['rss_till_date']) ? sanitize_text_field(wp_unslash( $_POST['rss_till_date'])) : '';
        $_POST['rss_filter_stats'] = isset($_POST['rss_filter_stats']) ? sanitize_text_field(wp_unslash($_POST['rss_filter_stats'])) : '';
        // Sanitize date parameters

        include( INTERQ_RSS_PI_PATH . 'app/templates/stats.php');
        die();
    }

    /**
     * Import any feeds
     */
    public function ajax_import(): void {
        global $interq_rss_post_importer;

        $this->load_options();

        // if there's nothing for processing or invalid data, bail
        if ( ! isset($_POST['feed']) || ! isset($_POST['interq_rss_pi_ajax_nonce']) || ! wp_verify_nonce(sanitize_key($_POST['interq_rss_pi_ajax_nonce']), 'interq_rss_pi_ajax_nonce_action') ) {
            wp_send_json_error(['message'=>'Invalid request']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }

        $_POST['feed'] = sanitize_key(wp_unslash($_POST['feed']));

        $_found = false;
        foreach ( $this->options['feeds'] as $id => $f ) {
            if ( $f['id'] == $_POST['feed'] ) {
                $_found = $id;
                break;
            }
        }
        if ( $_found === false ) {
            wp_send_json_error(['message'=>'wrong feed id provided']);
        }

        $post_count = 0;

        $f = $this->options['feeds'][$_found];

        $engine = new InterQ_Rss_Pi_Engine();

        // filter cache lifetime
        add_filter('wp_feed_cache_transient_lifetime', [$engine, 'frequency']);

        // prepare, import feed and count imported posts
        $items = $engine->do_import($f);
        if ( $items ) {
            $post_count += count($items);
        }

        remove_filter('wp_feed_cache_transient_lifetime', [$engine, 'frequency']);

        if ( $items === false ) {
            // there were an wp_error doing fetch_feed
            wp_send_json_error(['url'=>$f['url']]);
        }

        // reformulate import count
        $imports = intval($this->options['imports'] ?? 0) + $post_count;

        // update options
        $new_options = [
            'feeds' => $this->options['feeds'],
            'settings' => $this->options['settings'],
            'latest_import' => gmdate("Y-m-d H:i:s"),
            'imports' => $imports,
            'upgraded' => $this->options['upgraded'] ?? null
        ];
        // update in db
        update_option('interq_rss_pi_feeds', $new_options);

        global $interq_rss_post_importer;
        // reload options
        $interq_rss_post_importer->load_options();

        // log this
        $this->log->log($post_count);
//        InterQ_Rss_Pi_Log::log($post_count);

        wp_send_json_success(['count'=>$post_count, 'url'=>$f['url']]);

    }

    /**
     * Walker class function for category multiple checkbox
     *
     * @param int $post_id Post ID
     * @param int $descendants_and_self Category ID to list descendants of
     * @param array|false $selected_cats Selected category IDs, or false for none
     * @param array|false $popular_cats Popular category IDs, or false for none
     * @param Walker|null $walker Category walker instance
     * @param bool $checked_ontop Whether to move checked categories to the top
     * @return string
     */
    public function interq_rss_pi_category_checklist(
        int $post_id = 0,
        int $descendants_and_self = 0,
        $selected_cats = false,
        $popular_cats = false,
        ?Walker $walker = null,
        bool $checked_ontop = true
    ): string {

        $cat = "";
        if (empty($walker) || !is_a($walker, 'Walker'))
            $walker = new Walker_Category_Checklist;
        $descendants_and_self = (int) $descendants_and_self;
        $args = [];
        if (is_array($selected_cats))
            $args['selected_cats'] = $selected_cats;
        elseif ($post_id)
            $args['selected_cats'] = wp_get_post_categories($post_id);
        else
            $args['selected_cats'] = [];

        if ($descendants_and_self) {
            $categories = get_categories("child_of=$descendants_and_self&hierarchical=0&hide_empty=0");
            $self = get_category($descendants_and_self);
            array_unshift($categories, $self);
        } else {
            $categories = get_categories('get=all');
        }
        if ($checked_ontop) {
            // Post process $categories rather than adding an exclude to the get_terms() query to keep the query the same across all posts (for any query cache)
            $checked_categories = [];
            $keys = array_keys($categories);
            foreach ($keys as $k) {
                if (in_array($categories[$k]->term_id, $args['selected_cats'])) {
                    $checked_categories[] = $categories[$k];
                    unset($categories[$k]);
                }
            }
            // Put checked cats on top
            $cat .= call_user_func_array([$walker, 'walk'], [
                $checked_categories,
                0,
                $args
            ]);
        }
        // Then the rest of them
        $cat .= call_user_func_array([$walker, 'walk'], [
            $categories,
            0,
            $args
        ]);
        return $cat;
    }

    public function interq_rss_pi_tags_dropdown(string $fid, array $seleced_tags): void {

        if ($tags = get_tags(['orderby' => 'name', 'hide_empty' => false])) {

            echo '<select name="' . esc_html($fid) . '-tags_id[]" id="tag" class="postform">';

            foreach ($tags as $tag) {
                $strsel = "";
                if (!empty($seleced_tags)) {

                    if ($seleced_tags[0] == $tag->term_id) {
                        $strsel = "selected='selected'";
                    }
                }
                echo '<option value="' . esc_html($tag->term_id) . '" ' . esc_html($strsel) . '>' . esc_html($tag->name) . '</option>';
            }
            echo '</select> ';
        }
    }

    public function interq_rss_pi_tags_checkboxes(string $fid, array $seleced_tags): void {

        $tags = get_tags(['hide_empty' => false]);
        if ($tags) {
            $allowed_html = array(
                'li'    => array(),
                'label' => array(
                    'for' => array(),
                ),
                'input' => array(
                    'type'    => array(),
                    'name'    => array(),
                    'value'   => array(),
                    'id'      => array(),
                    'checked' => array(),
                ),
            );
            $checkboxes = "<ul>";

            foreach ( $tags as $tag ) :
                // Use checked() helper function for cleaner logic
                $checked = checked( in_array( $tag->term_id, $seleced_tags ), true, false );

                $checkboxes .= sprintf(
                    '<li>
                        <label for="tag-%1$s">
                            <input type="checkbox" name="%2$s-tags_id[]" value="%1$s" id="tag-%1$s" %3$s />
                            %4$s
                        </label>
                    </li>',
                    esc_attr( $tag->term_id ),             // %1$s
                    esc_attr( $fid ),                      // %2$s
                    $checked,                              // %3$s (checked() handles escaping)
                    esc_html( $tag->name )                 // %4$s
                );
            endforeach;

            $checkboxes .= '</ul>';

            echo wp_kses( $checkboxes, $allowed_html );
            
        }
    }

}
