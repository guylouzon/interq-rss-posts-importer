<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Manipulates log files
 *
 * @author mobilova UG (haftungsbeschränkt) <rsspostimporter@feedsapi.com>
 */
class InterQ_Rss_Pi_Log {

    /**
     * Initialise
     */
    public function init(): void {

        // hook ajax for loading and clearing log on admin screen
        add_action('wp_ajax_interq_rss_pi_load_log', [$this, 'load_log']);
        add_action('wp_ajax_interq_rss_pi_clear_log', [$this, 'clear_log']);
    }

    /**
     * Loads log contents
     */
    public function load_log(): void {
        if (! isset($_POST['interq_rss_pi_ajax_nonce']) || !wp_verify_nonce(sanitize_key($_POST['interq_rss_pi_ajax_nonce']), 'interq_rss_pi_ajax_nonce_action')) {
            wp_send_json_error(['message' => 'Invalid request']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }

        // get the log file's contents
        if (!file_exists(INTERQ_RSS_PI_LOG_PATH . 'log.txt')) {
            $log = 'No log file found.';
        }
        else {
            $log = file_get_contents(INTERQ_RSS_PI_LOG_PATH . 'log.txt');
        }

        // include the template to display it
        include(INTERQ_RSS_PI_PATH . 'app/templates/log.php');
        die();
    }

    public function clear_log(): void {
        if (!isset($_POST['interq_rss_pi_ajax_nonce']) || !wp_verify_nonce(sanitize_key($_POST['interq_rss_pi_ajax_nonce']), 'interq_rss_pi_ajax_nonce_action')) {
            wp_send_json_error(['message' => 'Invalid request']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }

        // get the log file
        $log_file = INTERQ_RSS_PI_LOG_PATH . 'log.txt';

        if (!file_exists($log_file)) {
            die();
        }

        // empty it
        file_put_contents($log_file, '');
        ?>
        <div id="message" class="updated">
            <p><strong><?php esc_html_e('Log has been cleared.', 'interq-rss-posts-importer'); ?></strong></p>
        </div>
        <?php
        die();
    }

    /**
     * Static method to add log messages
     * 
     * @global object $interq_rss_post_importer Global object
     * @param int $post_count Number of posts imported
     * @return void
     */
    public static function log(int $post_count, string $context = ''): void {

        global $interq_rss_post_importer;

        // if logging is disabled, return early. the setting is the string 'true' once saved from the settings form,
        // but the built in default is a boolean true, so both count as enabled
        $enable_logging = $interq_rss_post_importer->options['settings']['enable_logging'] ?? '';
        if ($enable_logging !== 'true' && $enable_logging !== true) {
            return;
        }

        // prepare the log entry
        $log = gmdate("Y-m-d H:i:s") . "\t Imported " . $post_count . " new posts." . ($context !== '' ? ' (' . $context . ')' : '') . " \n";

        // the log folder is created when the plugin loads, make sure it is still there (uploads cleaned, site moved)
        if (!is_dir(INTERQ_RSS_PI_LOG_PATH)) {
            wp_mkdir_p(INTERQ_RSS_PI_LOG_PATH);
        }

        $log_file = INTERQ_RSS_PI_LOG_PATH . 'log.txt';

        // add it to the log file
        file_put_contents($log_file, $log, FILE_APPEND);
    }

}

