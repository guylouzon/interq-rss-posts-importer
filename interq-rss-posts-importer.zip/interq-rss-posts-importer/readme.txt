=== InterQ Rss Posts Importer ===
Contributors: guylouzon
Plugin Name: InterQ Rss Posts Importer
Donate link: https://github.com/guylouzon/rss-posts-importer
Tags: rss aggregation, autoblog, rss feed, content curation, importer
Requires at least: 4.9
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2026.9.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

InterQ Rss Posts Importer is a powerful WordPress RSS Aggregator that imports full RSS posts as stand-alone articles on your blog.

== Description ==

**InterQ Rss Posts Importer** allows you to syndicate, import, and display Full Text RSS and Atom feeds on your WordPress site automatically. It fetches RSS feed items and publishes them as individual posts, making content curation and aggregation seamless.

Content syndication allows bloggers to share relevant content from other sources in their niche, providing value to readers with minimal manual effort.

= Core Features =
* **Automated Import:** Uses WordPress Cron to fetch feeds automatically.
* **Full Text Support:** Import entire article contents rather than just snippets.
* **Custom Assignment:** Set specific authors and categories per feed source.
* **SEO Optimized:** Options to append no-follow tags to outbound links and block search indexing for duplicate content protection.
* **Templating:** Simple system to format imported content, including backlinks and excerpts.


== Installation ==

1. Upload the `rss-post-importer` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to the InterQ Rss Posts Importer menu to configure your feed sources.


== Change Log ==

= 2026.9.2 =
* WordPress.org review compliance: removed PHP 8-only union types so the plugin activates cleanly on PHP 7.4 and later.
* The WordPress feed API is now loaded with a guarded require_once immediately before fetch_feed() is used.
* Automatic author import no longer creates user accounts from feed content; posts are assigned to an existing matching user or to the feed's configured author.
* The AJAX log load/clear handlers now require the manage_options capability in addition to a valid nonce.
* Removed the remaining PHP 8 union types from the category checklist parameters; the whole plugin now parses on PHP 7.4.

= 2026.9.1 =
* WordPress.org review compliance: all classes, options, hooks, AJAX actions and nonces now use the unique interq_rss_pi_ prefix, with automatic migration of existing settings and the old cron hook.
* Removed the FeedsAPI full-text integration: no external service is called anymore and keyword filtering works locally for all users.
* Log directory moved from wp-content/rsspi-log to the uploads folder; removed the raw POST debug log write.
* Text domain now matches the plugin slug (interq-rss-posts-importer); translation files renamed accordingly.
* Removed inline styles and unused template files.

= 2025.7.01 =
* Refresh: Full compatibility update for PHP 8.2+ and PHP 8.3.
* Security: Hardened input sanitization on settings save.
* Maintenance: Updated internal libraries for better performance.

= 2.5.2 =
* Bug fixing and improvement.

= 2.5.1 =
* Important security update.

= 2.5.0 =
* Security update.

= 2.0.0 =
* Re-factored and rewritten core logic.
* Added support for keyword/regex filtering.